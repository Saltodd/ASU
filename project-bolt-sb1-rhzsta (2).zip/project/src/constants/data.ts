import type { Course, Assignment, Announcement } from '../types';

export const courses: Course[] = [
  {
    code: 'MKT 591',
    name: 'Digital Marketing Strategy',
    instructor: 'Dr. Jennifer Martinez',
    credits: 3,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 9:30 AM - 10:45 AM'
  },
  {
    code: 'MKT 555',
    name: 'Marketing Analytics',
    instructor: 'Dr. Robert Chen',
    credits: 3,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 11:00 AM - 12:15 PM'
  },
  {
    code: 'MKT 570',
    name: 'Brand Management',
    instructor: 'Dr. Jennifer Martinez',
    credits: 3,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 2:00 PM - 3:15 PM'
  },
  {
    code: 'MKT 595',
    name: 'Marketing Research Methods',
    instructor: 'Dr. Robert Chen',
    credits: 2,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 3:30 PM - 4:45 PM'
  },
  {
    code: 'MKT 599',
    name: 'Special Topics in Digital Innovation',
    instructor: 'Dr. Jennifer Martinez',
    credits: 1,
    isOnline: false,
    meetingTime: 'Friday 10:00 AM - 10:50 AM'
  }
];

export const assignments: Assignment[] = [
  {
    id: '1',
    title: 'Social Media Campaign Analysis',
    course: 'MKT 591',
    dueDate: 'Dec 13, 2023',
    status: 'unsubmitted'
  },
  {
    id: '2',
    title: 'Market Segmentation Report',
    course: 'MKT 555',
    dueDate: 'Dec 15, 2023',
    status: 'completed'
  },
  {
    id: '3',
    title: 'Brand Strategy Presentation',
    course: 'MKT 570',
    dueDate: 'Dec 18, 2023',
    status: 'unsubmitted'
  },
  {
    id: '4',
    title: 'Final Marketing Plan',
    course: 'MKT 591',
    dueDate: 'Dec 20, 2023 11:59 PM',
    status: 'unsubmitted',
    description: 'Written report and presentation (25% of final grade)'
  }
];

export const announcements: Announcement[] = [
  {
    id: '1',
    course: 'MKT 591',
    title: 'Final Presentation Guidelines',
    date: 'Dec 18, 2023',
    preview: 'Updated requirements for final marketing plan presentations.',
    instructor: 'Dr. Jennifer Martinez'
  },
  {
    id: '2',
    course: 'MKT 555',
    title: 'Industry Guest Speaker',
    date: 'Dec 19, 2023',
    preview: 'Join us for a special presentation from Adobe\'s Marketing Analytics Director.',
    instructor: 'Dr. Robert Chen'
  },
  {
    id: '3',
    course: 'MKT 570',
    title: 'Extended Office Hours',
    date: 'Dec 20, 2023',
    preview: 'Additional office hours available Dec 18-22: Mon-Fri 2-4 PM via Zoom.',
    instructor: 'Dr. Jennifer Martinez'
  },
  {
    id: '4',
    course: 'ALL',
    title: 'Grade Submission Timeline',
    date: 'Dec 22, 2023',
    preview: 'Final grades will be posted by December 27th. Happy holidays!',
    instructor: 'Dr. Robert Chen'
  }
];