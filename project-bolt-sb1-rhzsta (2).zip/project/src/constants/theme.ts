export const colors = {
  primary: {
    maroon: '#8C1D40',
    gold: '#FFC627',
    darkMaroon: '#7C1535',
    lightGold: '#FFD45F'
  },
  gray: {
    50: '#FAFAFA',
    100: '#F5F5F5',
    200: '#EEEEEE',
    300: '#E0E0E0',
    400: '#BDBDBD',
    500: '#9E9E9E',
    600: '#757575',
    700: '#616161',
    800: '#424242',
    900: '#212121'
  },
  status: {
    success: '#4CAF50',
    warning: '#FFA000',
    error: '#D32F2F',
    info: '#1976D2'
  }
};

export const fonts = {
  primary: '"Arial", system-ui, sans-serif'
};