import type { Course, Assignment, Announcement } from '../types';

export const courses: Course[] = [
  {
    code: 'MKT 591',
    name: 'Digital Marketing Strategy',
    instructor: 'Dr. Jennifer Martinez',
    credits: 3,
    isOnline: false,
    meetingTime: 'Monday/Wednesday 10:30 AM - 11:45 AM'
  },
  {
    code: 'MKT 555',
    name: 'Marketing Analytics',
    instructor: 'Dr. Robert Chen',
    credits: 3,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 2:00 PM - 3:15 PM'
  },
  {
    code: 'MKT 570',
    name: 'Brand Management',
    instructor: 'Dr. Jennifer Martinez',
    credits: 3,
    isOnline: false,
    meetingTime: 'Monday/Wednesday 2:00 PM - 3:15 PM'
  },
  {
    code: 'MKT 585',
    name: 'Consumer Behavior Research',
    instructor: 'Dr. Robert Chen',
    credits: 3,
    isOnline: false,
    meetingTime: 'Tuesday/Thursday 10:30 AM - 11:45 AM'
  }
];

export const assignments: Assignment[] = [
  {
    id: '1',
    title: 'Digital Campaign Analysis',
    course: 'MKT 591',
    dueDate: 'Dec 15, 2023',
    status: 'unsubmitted'
  },
  {
    id: '2',
    title: 'Market Research Project',
    course: 'MKT 585',
    dueDate: 'Dec 18, 2023',
    status: 'completed'
  },
  {
    id: '3',
    title: 'Brand Strategy Presentation',
    course: 'MKT 570',
    dueDate: 'Dec 20, 2023',
    status: 'unsubmitted'
  }
];

export const announcements: Announcement[] = [
  {
    id: '1',
    course: 'MKT 591',
    title: 'Guest Speaker Next Week',
    date: 'Dec 18, 2023',
    preview: 'Join us for a special presentation from Google\'s Marketing Director.',
    instructor: 'Dr. Jennifer Martinez'
  },
  {
    id: '2',
    course: 'MKT 585',
    title: 'Research Symposium',
    date: 'Dec 19, 2023',
    preview: 'Present your research findings at the upcoming symposium.',
    instructor: 'Dr. Robert Chen'
  }
];