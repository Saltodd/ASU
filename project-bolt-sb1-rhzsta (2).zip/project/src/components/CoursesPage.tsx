import React from 'react';
import { BookOpen, Clock, User } from 'lucide-react';
import type { Course } from '../types';

interface CoursesPageProps {
  courses: Course[];
  onCourseSelect: (courseCode: string) => void;
}

export default function CoursesPage({ courses, onCourseSelect }: CoursesPageProps) {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <main className="ml-16 p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-start mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                My Courses
              </h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">
                Fall 2024
              </p>
            </div>
            <img
              src="https://s3-alpha-sig.figma.com/img/2feb/5d6c/270fa6fa41be73cc91c0fbe091127cd3?Expires=1733097600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=ewMBIKMNxFZY~qyNBK-FWvWbuvHvB3gxljKp~HE7jHQ6YMzcHqxguBc993PB3L7gyPNgddMS6v~N9IBPsdet6J8zaOmkGD6ypFZtpeeCYAT4XQAguBonXHVPE2TpgBtn3YExzx~0-qYFxZJMu6sfXAVLfYpTB9LxxeMbnJaWtk79O81x5iwbAnKxPJWSkzsRpYqfpheLUD-he2LugBz75mMhDy5D7ikBJKg9ghcMeUDc74ZwPWpLl4Id~5bfrOGOGN~MAvCMyVJP2qGlxhIMkzmgqujE9Z2yh5EFeKEJt4shgfQM0N8FlqFw3aZPCT-pT7B3l2O2BHq37GcfTT909Q__"
              alt="JMU Logo"
              className="w-[500px] -mt-4"
            />
          </div>

          <div className="grid gap-6">
            {courses.map((course) => (
              <button
                key={course.code}
                onClick={() => onCourseSelect(course.code)}
                className="bg-white dark:bg-gray-800 rounded-xl shadow-md p-6 text-left hover:ring-2 hover:ring-purple-500 transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-4">
                    <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                      <BookOpen className="h-6 w-6 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                        {course.code}: {course.name}
                      </h3>
                      <div className="mt-2 flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400">
                        <div className="flex items-center">
                          <User className="h-4 w-4 mr-1" />
                          {course.instructor}
                        </div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {course.meetingTime}
                        </div>
                      </div>
                      <div className="mt-2">
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-200">
                          {course.credits} {course.credits === 1 ? 'Credit' : 'Credits'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}