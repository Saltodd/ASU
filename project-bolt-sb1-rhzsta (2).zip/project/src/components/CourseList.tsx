import React from 'react';
import { BookOpen } from 'lucide-react';
import type { Course } from '../types';

interface CourseListProps {
  courses: Course[];
  onCourseSelect: (courseCode: string) => void;
}

export default function CourseList({ courses, onCourseSelect }: CourseListProps) {
  const totalCredits = courses.reduce((sum, course) => sum + course.credits, 0);

  return (
    <div className="bg-white rounded-xl shadow-md">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <h2 className="text-xl font-semibold text-gray-900">
            Current Courses
          </h2>
          <div className="bg-maroon/10 px-3 py-1 rounded-lg">
            <span className="text-sm text-maroon font-medium">
              {totalCredits} Credits
            </span>
          </div>
        </div>
        <div className="space-y-4">
          {courses.map(course => (
            <button
              key={course.code}
              onClick={() => onCourseSelect(course.code)}
              className="w-full flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:border-maroon transition-colors text-left bg-white"
            >
              <div className="flex-shrink-0">
                <BookOpen className="h-5 w-5 text-gray-400" />
              </div>
              <div>
                <h3 className="font-medium text-gray-900">
                  {course.code}: {course.name}
                </h3>
                <p className="text-sm text-gray-500">
                  {course.instructor} • {course.credits} credits
                </p>
                {course.meetingTime && (
                  <p className="text-sm text-gray-500">
                    {course.meetingTime}
                  </p>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}