import React, { useState } from 'react';
import Navigation from './Navigation';
import CalendarView from './CalendarView';
import CoursePage from './CoursePage';
import AssignmentList from './AssignmentList';
import AnnouncementList from './AnnouncementList';
import CourseList from './CourseList';
import { courses, assignments, announcements } from '../constants/data';

export default function Dashboard() {
  const [showCalendar, setShowCalendar] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [activePage, setActivePage] = useState('dashboard');

  const selectedCourseData = courses.find(course => course.code === selectedCourse);

  if (selectedCourse && selectedCourseData) {
    return (
      <CoursePage 
        course={selectedCourseData}
        onBack={() => setSelectedCourse(null)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-tan-light text-gray-900">
      <Navigation 
        onCalendarClick={() => setShowCalendar(true)}
        activePage={activePage}
        onPageChange={setActivePage}
      />
      
      <main className="lg:ml-16 p-4 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row justify-between items-center lg:items-start mb-8 space-y-4 lg:space-y-0">
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 text-center lg:text-left">
                Welcome, McKenzie Kear
              </h1>
              <p className="text-gray-700 mt-2 text-center lg:text-left">
                Master's in Business Marketing (Online) - Fall 2024
              </p>
              <div className="mt-4 flex items-center justify-center lg:justify-start space-x-4">
                <div className="bg-maroon/10 px-4 py-2 rounded-lg">
                  <span className="text-maroon font-medium">
                    12 Graduate Credits
                  </span>
                </div>
              </div>
            </div>
            <img
              src="https://www.asu.edu/asuthemes/5.0/assets/arizona-state-university-logo.png"
              alt="Arizona State University"
              className="w-[200px] lg:w-[300px]"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 lg:gap-8">
            <div className="lg:col-span-2 space-y-4 lg:space-y-6">
              <AssignmentList 
                assignments={assignments}
                onAssignmentClick={setSelectedCourse}
              />
              <AnnouncementList 
                announcements={announcements}
                onAnnouncementClick={setSelectedCourse}
              />
            </div>

            <div className="space-y-4 lg:space-y-6">
              <CourseList 
                courses={courses}
                onCourseSelect={setSelectedCourse}
              />
            </div>
          </div>
        </div>
      </main>

      {showCalendar && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 lg:p-8 z-50">
          <CalendarView 
            courses={courses}
            onClose={() => setShowCalendar(false)}
            onCourseClick={setSelectedCourse}
          />
        </div>
      )}
    </div>
  );
}