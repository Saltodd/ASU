import React from 'react';
import { Clock } from 'lucide-react';
import type { Assignment } from '../types';

interface AssignmentListProps {
  assignments: Assignment[];
  onAssignmentClick: (courseCode: string) => void;
}

export default function AssignmentList({ assignments, onAssignmentClick }: AssignmentListProps) {
  return (
    <div className="bg-white rounded-xl shadow-md">
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Upcoming Assignments
        </h2>
        <div className="space-y-4">
          {assignments.map(assignment => (
            <div
              key={assignment.id}
              onClick={() => onAssignmentClick(assignment.course)}
              className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:border-maroon transition-colors cursor-pointer bg-white"
            >
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0">
                  <Clock className="h-5 w-5 text-gray-400" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">
                    {assignment.title}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {assignment.course} • Due {assignment.dueDate}
                  </p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                assignment.status === 'completed'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {assignment.status === 'completed' ? 'Completed' : 'Unsubmitted'}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}