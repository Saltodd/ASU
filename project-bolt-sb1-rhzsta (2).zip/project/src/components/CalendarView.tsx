import React from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import type { Course } from '../types';

interface CalendarViewProps {
  courses: Course[];
  onClose: () => void;
  onCourseClick: (courseCode: string) => void;
}

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
const timeSlots = Array.from({ length: 14 }, (_, i) => i + 8); // 8 AM to 9 PM

export default function CalendarView({ courses, onClose, onCourseClick }: CalendarViewProps) {
  const [currentWeek, setCurrentWeek] = React.useState(new Date());

  const getCourseForTimeSlot = (day: string, hour: number) => {
    return courses.find(course => {
      if (!course.meetingTime) return false;
      
      const [dayPart, timePart] = course.meetingTime.split(' ');
      const courseDays = dayPart.split('/');
      
      if (!courseDays.includes(day)) return false;

      const [timeRange] = timePart.split(' - ');
      const [timeHour, timeMinute] = timeRange.split(':');
      let courseHour = parseInt(timeHour);
      
      if (timeRange.includes('PM') && courseHour !== 12) {
        courseHour += 12;
      }

      return hour === courseHour;
    });
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-md max-h-[90vh] w-full max-w-6xl overflow-hidden flex flex-col">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setCurrentWeek(new Date(currentWeek.setDate(currentWeek.getDate() - 7)))}
            className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <h2 className="text-lg lg:text-xl font-semibold">
            Week of {currentWeek.toLocaleDateString('en-US', { month: 'long', day: 'numeric' })}
          </h2>
          <button
            onClick={() => setCurrentWeek(new Date(currentWeek.setDate(currentWeek.getDate() + 7)))}
            className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
        <button
          onClick={onClose}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="p-4 overflow-auto">
        <div className="min-w-[800px]">
          <div className="grid grid-cols-6 gap-2">
            <div className="sticky left-0 bg-white dark:bg-gray-800 z-10"></div>
            {weekDays.map(day => (
              <div key={day} className="text-center font-semibold py-2 text-sm lg:text-base">
                {day}
              </div>
            ))}
          </div>

          <div className="relative">
            {timeSlots.map(hour => (
              <div key={hour} className="grid grid-cols-6 gap-2">
                <div className="sticky left-0 bg-white dark:bg-gray-800 text-right pr-4 py-2 text-xs lg:text-sm z-10">
                  {hour % 12 || 12}:00 {hour >= 12 ? 'PM' : 'AM'}
                </div>
                {weekDays.map(day => {
                  const course = getCourseForTimeSlot(day, hour);
                  return (
                    <div
                      key={`${day}-${hour}`}
                      className={`border border-gray-200 dark:border-gray-700 p-2 min-h-[60px] lg:min-h-[80px] ${
                        course ? 'bg-purple-100 dark:bg-purple-900/30 cursor-pointer hover:bg-purple-200 dark:hover:bg-purple-900/50 transition-colors' : ''
                      }`}
                      onClick={() => course && onCourseClick(course.code)}
                    >
                      {course && (
                        <div className="text-xs lg:text-sm">
                          <div className="font-medium">{course.code}</div>
                          <div className="text-xs text-gray-600 dark:text-gray-400 truncate">
                            {course.name}
                          </div>
                          <div className="text-xs text-gray-500 hidden lg:block">
                            {course.instructor}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}