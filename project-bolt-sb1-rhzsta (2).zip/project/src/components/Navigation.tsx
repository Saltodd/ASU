import React from 'react';
import { LayoutDashboard, BookOpen, Calendar, Inbox, HelpCircle, Menu } from 'lucide-react';

interface NavigationProps {
  onCalendarClick: () => void;
  activePage: string;
  onPageChange: (page: string) => void;
}

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '#' },
  { icon: BookOpen, label: 'Courses', href: '#' },
  { icon: Calendar, label: 'Calendar', href: null },
  { icon: Inbox, label: 'Inbox', href: '#' },
  { icon: HelpCircle, label: 'Help', href: '#' },
];

export default function Navigation({ onCalendarClick, activePage, onPageChange }: NavigationProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  return (
    <>
      <button
        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        className="fixed top-4 left-4 z-50 lg:hidden bg-maroon text-white p-2 rounded-lg hover:bg-maroon-dark transition-colors"
      >
        <Menu className="h-6 w-6" />
      </button>

      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      <nav className={`fixed top-0 left-0 h-full bg-maroon transition-transform duration-300 z-40
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        w-64 lg:w-16`}
      >
        <div className="flex flex-col items-center py-4 space-y-4">
          {navItems.map((item) => {
            const isActive = item.label.toLowerCase() === activePage;
            return (
              <button
                key={item.label}
                onClick={() => {
                  if (item.label === 'Calendar') {
                    onCalendarClick();
                  } else {
                    onPageChange(item.label.toLowerCase());
                  }
                  setIsMobileMenuOpen(false);
                }}
                className={`w-full flex items-center px-4 py-3 transition-colors
                  ${isActive 
                    ? 'bg-gold text-maroon [&_svg]:stroke-maroon font-medium' 
                    : 'text-white hover:bg-gold hover:text-maroon [&_svg]:stroke-white hover:[&_svg]:stroke-maroon'
                  }`}
              >
                <item.icon className="h-5 w-5 transition-colors" />
                <span className="ml-3 lg:hidden">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}