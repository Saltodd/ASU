import React from 'react';
import type { Announcement } from '../types';

interface AnnouncementListProps {
  announcements: Announcement[];
  onAnnouncementClick: (courseCode: string) => void;
}

export default function AnnouncementList({ announcements, onAnnouncementClick }: AnnouncementListProps) {
  return (
    <div className="bg-white rounded-xl shadow-md">
      <div className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">
          Course Announcements
        </h2>
        <div className="space-y-4">
          {announcements.map(announcement => (
            <div
              key={announcement.id}
              onClick={() => onAnnouncementClick(announcement.course)}
              className="p-4 border border-gray-200 rounded-lg hover:border-maroon transition-colors cursor-pointer bg-white"
            >
              <div className="flex justify-between items-start">
                <h3 className="font-medium text-gray-900">
                  {announcement.title}
                </h3>
                <span className="text-sm text-gray-500">
                  {announcement.date}
                </span>
              </div>
              <p className="text-sm text-gray-600 mt-1">
                {announcement.preview}
              </p>
              <div className="mt-2 text-sm text-gray-500">
                {announcement.course} • {announcement.instructor}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}