export interface Course {
  code: string;
  name: string;
  meetingTime?: string;
  instructor: string;
  credits: number;
  isOnline: boolean;
}

export interface Assignment {
  id: string;
  title: string;
  course: string;
  dueDate: string;
  status: 'completed' | 'unsubmitted';
}

export interface Announcement {
  id: string;
  course: string;
  title: string;
  date: string;
  preview: string;
  instructor: string;
}