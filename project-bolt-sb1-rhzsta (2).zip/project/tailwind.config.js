/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        maroon: {
          DEFAULT: '#8C1D40',
          dark: '#7C1535',
          light: '#A32447'
        },
        gold: {
          DEFAULT: '#FFC627',
          dark: '#FFB300',
          light: '#FFD45F'
        },
        tan: {
          light: '#F4EFE1',
          DEFAULT: '#E6DFD1',
          dark: '#D8D1C3'
        },
        gray: {
          50: '#FAFAFA',
          100: '#F5F5F5',
          200: '#EEEEEE',
          300: '#E0E0E0',
          400: '#BDBDBD',
          500: '#9E9E9E',
          600: '#757575',
          700: '#616161',
          800: '#424242',
          900: '#212121'
        }
      },
      fontFamily: {
        sans: ['Arial', 'system-ui', 'sans-serif']
      }
    }
  },
  plugins: []
};